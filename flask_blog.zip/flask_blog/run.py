from flasky import app

if __name__ == ('__main__'): #allows for app to run directly from script
    app.run(debug=True)
