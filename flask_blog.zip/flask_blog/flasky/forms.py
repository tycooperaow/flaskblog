from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from flask_login import current_user
from wtforms import StringField, PasswordField, SubmitField, BooleanField, TextAreaField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError
from flasky.models import User

class Register(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=25)])

    email = StringField('Email', validators=[DataRequired(), Email() ])

    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')]) #check to see if both passwords are equal
    submitRegister = SubmitField('Sign-Up')
    #makesure they username  has a valid character
    # Make sure the sting is not too long
    #Length() checks the length size of the string
    def validate_username(self, username):
        user = User.query.filter_by(username = username.data).first()
        if user:
            raise ValidationError('Username already exist. Please choose another one!')

    def validate_email(self, email):
        email = User.query.filter_by(email = email.data).first()
        if email:
            raise ValidationError('Email already has an account. Please choose another one!')

class Login(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=20)])

    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember me')#remembers the user using a secured cookie
    submitLogin = SubmitField('Login')

#Secret KEy protects against site modifaction

class UpdateAccount(FlaskForm): #located on the account page. Allows the user to update their account
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=25)])

    email = StringField('Email', validators=[DataRequired(), Email() ])
    pic = FileField('Update Profile Picture', validators=[FileAllowed(['jpg', 'jpeg', 'png', 'tiff'])])
    update = SubmitField('Update')
    #makesure they username  has a valid character
    # Make sure the sting is not too long
    #Length() checks the length size of the string
    def validate_username(self, username):
        if username.data != current_user.username:
            user = User.query.filter_by(username = username.data).first()
            if user:
                raise ValidationError('Username already exist. Please choose another one!')
    def validate_email(self, email):
        if email.data != current_user.email:
            email = User.query.filter_by(email = email.data).first()
            if email:
                raise ValidationError('Email already has an account. Please choose another one!')

class NewPost(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    post_content = TextAreaField('Content',  validators=[DataRequired()])
    postit = SubmitField('Post')

class RequestReset(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email() ])
    submitReset = SubmitField('Request Password Reset')

    def validate_email(self, email):
        email = User.query.filter_by(email = email.data).first()
        if None:
            raise ValidationError('There is no account with this email. You must register first!')

class ResetPassword(FlaskForm):
    password = PasswordField('New Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')]) #check to see if both passwords are equal
    submitRegister = SubmitField('Reset Password')
