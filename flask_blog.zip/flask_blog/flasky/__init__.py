import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from flask_mail import Mail

app =Flask(__name__)
app.config['SECRET_KEY'] = '1435406a1eeebae547528fe087e54092'
#apps are consistently updating
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
#/// slashes states the diretion for the path
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'loginFunc'
login_manager.login_message_category = 'info'
app.config['MAIL_SERVER'] = 'smtp.gmail.com' #SMTP SIMPLE MAIL TRANSFER PROTOCOL
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.environ.get('DB_USER')
app.config['MAIL_PASSWORD'] = os.environ.get('DB_Pass')
mail = Mail(app)
#use enviroment variables to hide sensitve information
from flasky import route
