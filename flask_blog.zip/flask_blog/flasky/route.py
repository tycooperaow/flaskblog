import os #grabs file extention from uploaded file
import secrets
from PIL import Image
from flask import render_template, url_for, flash, redirect, request, abort
from flasky import app, db, Bcrypt, mail
from flasky.forms import Register, Login, UpdateAccount, NewPost, RequestReset, ResetPassword
from flasky.models import User, Post
from flask_login import login_user, current_user, logout_user, login_required
from flask_mail import Message

bcrypt = Bcrypt(app)

@app.route("/") #this is a decorartor to route to any other app page
@app.route("/home")
def home():
    page = request.args.get('page', 1, type=int) #grabs the page we need
    posts = Post.query.order_by(Post.date_db.desc()).paginate(page=page, per_page=2)
    #triple quotes opens up a multi-line string to copy and paste entire html code
    return render_template("home.html", posts=posts)

@app.route("/about")
def aboutPage():
    return render_template("about.html", title="About")

@app.route("/motivate")
def motivatePage():
    return render_template("motivate.html", title="Motivation")

@app.route("/register", methods=['GET', 'POST'])
def registerFunc():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = Register()
    if form.validate_on_submit(): #checks if form validated when submitted
        hashed_pwd = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, email= form.email.data, password=hashed_pwd)
        db.session.add(user)
        db.session.commit()
        flash(f'Account created for {form.username.data}!', 'success') #f string is for passing in a variable.#flashes message that an account has been created
        return redirect(url_for('loginFunc'))
    return render_template('register.html', title='Register', form=form)


@app.route("/login",  methods=['GET', 'POST'])
def loginFunc():
    form = Login()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            flash('Login unsuccessful. Please check your username and password')
    return render_template('login.html', title='Login', form=form)


@app.route("/logout")
def logoutFunc():
        logout_user()
        return redirect(url_for('home'))

def save_pic(form_pic):
    random_hex = secrets.token_hex(8)#makes a random hex string for the name of the picture file
    _ , f_ext = os.path.splitext(form_pic.filename)#returns file name with and without extention
    pic_fn = random_hex + f_ext #renames picture
    pic_path = os.path.join(app.root_path, 'static/profile_pics', pic_fn)
    output_size = (125, 125)
    i = Image.open(form_pic)
    i.thumbnail(output_size)
    i.save(pic_path)

    return pic_fn


@app.route("/account", methods=['GET', 'POST']) #posting form back to an account
@login_required
def account():
    form = UpdateAccount()
    if form.validate_on_submit(): #checks if form is valid when submitted
        if form.pic.data: #if the form submission is the picture
            pic_file = save_pic(form.pic.data)
            current_user.profile_Image = pic_file
        current_user.username = form.username.data #
        current_user.email = form.email.data #
        db.session.commit() #
        flash('Your account has been updated!', 'success') #tells users that account has been updated
        return redirect(url_for('account'))
        #redirect  instead of rendering template. Post-redirect-pattern, browser send another post request when page is reloaded
    elif request.method =='GET':
        form.username.data = current_user.username
        form.email.data = current_user.email

    profile_Image = url_for('static', filename='profile_pics/' + current_user.profile_Image) # Allows the image to appear

    return render_template('account.html', title= "Account", profile_Image=profile_Image, form=form)

@app.route("/post/new", methods=['GET', 'POST'])
@login_required
def new_post():
    form = NewPost()
    if form.validate_on_submit():
        post = Post(title_db=form.title.data, content_db=form.post_content.data, author = current_user)
        db.session.add(post)
        db.session.commit()
        flash('Your post has been created!',  'success')
        return redirect(url_for('home'))
    return render_template('newPost.html', title= "New Post", form = form, author = current_user, egend= "New Post")

@app.route("/posts/<int:post_id>")
def post(post_id):
        post = Post.query.get_or_404(int(post_id)) #Give the post with the id, if it doens't exist, then return 404 method
        return render_template('post.html', title=post.title_db, posts=post)

@app.route("/posts/<int:post_id>/update",  methods=['GET', 'POST'])
def update_post(post_id):
    post = Post.query.get_or_404(int(post_id)) #Give the post with the id, if it doens't exist, then return 404 method
    if post.author != current_user: #forbiddens any user who is not the author form editing the post
        abort(403)
    form = NewPost()
    if form.validate_on_submit():
        post.title_db = form.title.data
        post.content_db = form.post_content.data
        db.session.commit()
        flash('Your post has been updated!', 'success')
        return redirect(url_for('post', post_id=post.id))

    elif request.method == 'GET':
        form.title.data = post.title_db
        form.post_content.data = post.content_db
    return render_template('newPost.html', title= "Update Post", form = form, author = current_user, legend= "Edit Post")

@app.route("/posts/<int:post_id>/delete",  methods=['POST']) #deletes a post for a user
def delete_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.author !=current_user:
        abort(403)
    db.session.delete(post)
    db.session.commit()
    flash('Your post has been successfully deleted.', 'success')
    return redirect(url_for('home'))

@app.route("/user/<string:username>") #Displays post from only one user
def user_post(username):
    page = request.args.get('page', 1, type=int) #grabs the page we need
    user = User.query.filter_by(username=username).first_or_404()
    posts = Post.query.filter_by(author=user)\
        .order_by(Post.date_db.desc())\
        .paginate(page=page, per_page=4)
    #triple quotes opens up a multi-line string to copy and paste entire html code
    return render_template("user.html", posts=posts, user=user)

def send_reset_email(user):
    token = user.get_reset_token()
    msg = Message ('Password Reset Request', sender ='priestcrypto@gmail.com', recipients=[user.email])
    msg.body = f''' To reset your password, please visit the following link:
{url_for('reset_token', token=token, _external=True)}

If you did not make this request, then simply ignore this email. No action will be taken
    '''
    mail.send(msg)

@app.route("/reset_password", methods=['GET', 'POST'])
def reset_request():
    if current_user.is_authenticated: #checks if form is valid when submitted
        return redirect(url_for('home'))
    form = RequestReset()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        send_reset_email(user)
        flash('An email has been sent with instructions to reset your password!', 'info')
        return redirect(url_for('loginFunc'))
    return render_template('reset_request.html', title='Reset Password', form=form)

@app.route("/reset_password/<token>", methods=['GET', 'POST'])
def reset_token(token):
    if current_user.is_authenticated: #checks if form is valid when submitted
        return redirect(url_for('home'))
    user = User.verify_reset_token(token) #invalid ot expired
    if user is None:
        flash('This is an invalid or expired token', 'warning')
        return redirect(url_for('reset_request'))
    form = ResetPassword()
    if form.validate_on_submit(): #checks if form validated when submitted
        hashed_pwd = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user.password = hashed_pwd
        db.session.commit()
        flash('Your password has been updated for your account at {form.username.data}!', 'success') #f string is for passing in a variable.#flashes message that an account has been created
        return redirect(url_for('loginFunc'))
    return render_template("reset_token.html", title="Reset Password", form=form)
